sqroot=int(input("enter a number:"))
num=sqroot**0.5
print("the sqroot of a number is ",num)
