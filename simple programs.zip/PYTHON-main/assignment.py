employee ={"name":"johnny","age":32,"salary":26000,"company":"tcs"}
print(type(employee))
print(employee)
print(employee.keys())
print(employees.values())
