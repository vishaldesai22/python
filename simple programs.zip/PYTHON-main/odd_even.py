num=int(input("enter a number :"))
if num%2==0 :
    print(f"The given number {num} is a even number")
else :
    print(f"The given number {num} is a odd number")
