
#min function
i=min(10,20)
print(i)

#max function 
m= max(10,20, 30)
print(m)

#pow function
p=pow(2,3)
print(p)

#round
r= round(10.60)
print(r)


