r = float(input("enter radius of cylinder:"))
h = float(input("enter height of cylinder:"))
surface_area = (2*22*(r + h))/7 
print ("Surface Area Of Cylinder is:",surface_area);  
