width=int(input("enter width of rectangle:"))
height=int(input("enter height of rectangle:"))
area_of_rect=width*height
print("area of rectangle :",area_of_rect)
