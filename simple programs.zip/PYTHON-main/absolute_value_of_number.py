n=int(input("enter a number : "))
absolute_value=abs(n)
print(f"The absolute value of {n} is {absolute_value}")
