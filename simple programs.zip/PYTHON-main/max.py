n1=10
n2=20
n3=30

print(max(n1,n2,n3))
