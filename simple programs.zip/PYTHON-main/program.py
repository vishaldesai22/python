import math
w=math.ceil(12.12)
print (w)

f=math.floor(12.99)
print(f)


c= math.cos(90)
print(c)

e= math.exp(3)
print(e)

m= math.factorial(5)
print(m)

g=math.fmod(50,10)
print (g)

d=math.sqrt(30)
print(d)

t= math.trunc(12.4444)
print(t)

s=math.copysign(-10,12)
print(s)
