x = 5
y = 10

x, y = y, x
print("x =", x)
print("y =", y)
