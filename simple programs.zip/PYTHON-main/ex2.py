
#specific fun.
from example import add
print(add(12,12))



#multiple function
from example import add,sub,mul
print(add(13,14))
print (sub(44,33))
print(mul(10,1))

#all the functions

from example import *
print(div(10,5))

