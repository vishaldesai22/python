us=int(input("enter us dollar here :"))
ind=us*82.53
print("indian currency is :",ind)
