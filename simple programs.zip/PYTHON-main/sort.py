A=[24,25,354,67,667]
A.sort()
print(A)
