resume = '''
Name: Tushar Ravindra Kurane
Age: 19
Address: Gadhinglaj
Email: tusharkurane209@gmail.com
Phone: 8605527692

Education:
Diploma in Computer Engineering
Sant Gajanan Maharaj Rural Polytechnic Mahagaon, June 2022

High School
Sadhana High School Gadhinglaj

Coding Languages: C, C++, Java, Python, VB.net, JavaScript

Other Skills: Editing, Quick learner, Good listener

Hobbies: Football, Playing video games

Strengths: Like exploring things, Good enough logical thinking, Ambitious

Weaknesses: Sometimes lazy, Cannot do multitasking well, Cannot focus on one task
s
'''

print(resume)
