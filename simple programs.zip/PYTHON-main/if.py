a=5000
b=1100
if a<b :
    print("B is greater than A")
else :
    print("A is greater than B")
    






