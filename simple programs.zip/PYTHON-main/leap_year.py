year=int(input("Enter any Year:"))

while(year%4==0):
    print("The year you entered is a leap year")
    break
