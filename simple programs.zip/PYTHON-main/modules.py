def add1(x,y):
    return (x+y)
