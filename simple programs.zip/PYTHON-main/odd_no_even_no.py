num=int(input("enter any number :"))
if num%2==0 :
    print("The number you entered is a even number")
else:
    print("The number you entered is a odd number")





