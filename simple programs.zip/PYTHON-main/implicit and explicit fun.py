# implicit function 
'''a=10
b=20.20
c= a+b
print(c)
'''

#explicit function
'''x=10
#print (x)
q=float(x)
print(x)
a= type(q)
print(a)
print(q)
'''

#eval function
'''w= eval('1+2')
print(w)
'''

#unichr
'''a=65
o=unichr(a)
print(o)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           i
'''

#hexadecimal
'''s=hex(12)
print(s)
'''

#octal
'''d= oct (6)
print(d)
'''

#

