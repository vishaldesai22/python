
#right align
x=100000
o=format(x,'>10.2f')
print(o)

#left align
o=format(x,'<10.2f')
print(o)

#carat center align

o=format(x,'^10.2f')
print(o)

#positive negative
o=format(x,'+')
print(o)

#negative

o=format(x,'-')
print(o)


#underscore
o=format(x,'_')
print(o)

#binary format
o=format(x,'b')
print(o)

#decimal format
o=format(x,'d')
print(o)

#octal format
o=format(x,'o')
print(o)

#lower case
o=format(x,'x')
print(o)

#lower case
o=format(x,'X')
print(o)















































    
