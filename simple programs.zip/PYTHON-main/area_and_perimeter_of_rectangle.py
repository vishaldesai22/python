s=int(input("enter sides of rectangle : "))
area=s*s
perimeter=4*s
print("Area of Rectangle : ",area)
print("Perimeter of Rectangle : ",perimeter)
